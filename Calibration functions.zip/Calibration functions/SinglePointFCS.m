function [corrBins, SP_FCS, w, f, z] = SinglePointFCS(SP,sampleFreq)

%Calculate ACF, fit the data, and get fitted parameters

rows         = 1;
cols         = 1; 
mfirstCol    = 1;
mlastCol     = 1;
radius       = 0; 
sampleFreq; 
ReverseOrder = false; 

[XCF_ret, XCF_av, all_corrBins]=pcf_batch(SP,radius,mfirstCol,mlastCol,sampleFreq,ReverseOrder);

corrBins = all_corrBins{1,1};

SP_FCS = cell2mat(XCF_av);   % Get average ACF profile

%Fit the ACF to a one component model for a 3D PSF, get the lateral PSF size

[w,f]=FitCalibration(corrBins,SP_FCS);
z=3.*w;

end


