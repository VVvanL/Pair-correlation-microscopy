To detrend data:

1. Open "detrend_line.m" file

2. Write in the command window:

[datad]=detrend_line(data1,2000,3)


Information:

data1=data from TIF file

2000=binsize (moving average)

3=method used (moving average)
